﻿using System.ComponentModel.DataAnnotations;
using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace TaskManagement.Models
{
    public class Task
    {
        public int Id { get; set; }

        [Required]
        public string Title { get; set; }

        public string Description { get; set; }

        [Required]
        [DataType(DataType.Date)]
        [CustomValidation(typeof(Task), nameof(ValidateDueDate))]
        public DateTime DueDate { get; set; }

        [Required]
        public string Status { get; set; } // Pending, In Progress, Completed

        public static ValidationResult ValidateDueDate(DateTime dueDate, ValidationContext context)
        {
            return dueDate >= DateTime.Today
                ? ValidationResult.Success
                : new ValidationResult("Due date cannot be in the past.");
        }

        public class TaskDbContext : DbContext
        {
            public TaskDbContext(DbContextOptions<TaskDbContext> options) : base(options) { }

            public DbSet<Task> Tasks { get; set; }
        }
    }
}
